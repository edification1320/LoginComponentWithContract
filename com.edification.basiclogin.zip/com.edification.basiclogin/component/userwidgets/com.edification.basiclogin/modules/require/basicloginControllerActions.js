define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onDone defined for tbxUserName **/
    AS_TextField_g15661516d354eaeb172bc67097a85fa: function AS_TextField_g15661516d354eaeb172bc67097a85fa(eventobject, changedtext) {
        var self = this;
        if (self.validateUsername) {
            self.validateUsername();
        }
    },
    /** onDone defined for tbxPassword **/
    AS_TextField_e0046a99df7445aab7bd23841d180b92: function AS_TextField_e0046a99df7445aab7bd23841d180b92(eventobject, changedtext) {
        var self = this;
        if (self.validatePassword) {
            self.validatePassword();
        }
    },
    /** onClick defined for btnLogin **/
    AS_Button_f6bfba80095f407dabbc3736b9f6f729: function AS_Button_f6bfba80095f407dabbc3736b9f6f729(eventobject) {
        var self = this;

        function INVOKE_IDENTITY_SERVICE__e5d20925596b4317a0919818048e1147_Success(response) {
            if (self.loginSuccessEvent) {
                self.loginSuccessEvent(response);
            }
        }
        function INVOKE_IDENTITY_SERVICE__e5d20925596b4317a0919818048e1147_Failure(error) {
            if (self.loginFailureEvent) {
                self.loginFailureEvent(error);
            }
        }
        if (login_inputparam == undefined) {
            var login_inputparam = {};
        }
        login_inputparam["serviceID"] = "UserRepository$login";
        login_inputparam["operation"] = "login";
        login_inputparam["userid"] = self.view.tbxUserName.text;
        login_inputparam["password"] = self.view.tbxPassword.text;
        UserRepository$login = mfidentityserviceinvoker("UserRepository", login_inputparam, INVOKE_IDENTITY_SERVICE__e5d20925596b4317a0919818048e1147_Success, INVOKE_IDENTITY_SERVICE__e5d20925596b4317a0919818048e1147_Failure);
    }
});